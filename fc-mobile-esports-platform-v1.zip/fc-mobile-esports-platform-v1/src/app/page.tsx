const tournaments = [
  {name:"Ultimate Division Rival", status:"LIVE", teams:"16 Teams", prize:"৳50,000"},
  {name:"Syndicate Champions Cup", status:"UPCOMING", teams:"32 Teams", prize:"৳100,000"},
  {name:"FC Mobile League Finals", status:"COMPLETED", teams:"8 Teams", prize:"৳25,000"}
];

const features = [
  "Tournament Registration",
  "Automatic Fixtures",
  "Live Standings",
  "Player Statistics",
  "Leaderboards",
  "Admin Control"
];

export default function Home(){
  return (
    <main className="container">
      <header>
        <p className="brand">THE SYNDICATE • FC MOBILE ESPORTS</p>
        <h1>COMPETE.<br/>MANAGE.<br/>DOMINATE.</h1>
        <p className="subtitle">
          A professional tournament management platform built for competitive FC Mobile communities.
        </p>
      </header>

      <section className="heroCard">
        <span>LIVE TOURNAMENT</span>
        <h2>Ultimate Division Rival — Season 01</h2>
        <div className="stats">
          <b>16<br/><small>Teams</small></b>
          <b>120<br/><small>Matches</small></b>
          <b>194<br/><small>Goals</small></b>
        </div>
      </section>

      <h2>Tournaments</h2>
      <section className="grid">
        {tournaments.map(t=>(
          <article key={t.name}>
            <span>{t.status}</span>
            <h3>{t.name}</h3>
            <p>{t.teams}</p>
            <strong>{t.prize}</strong>
          </article>
        ))}
      </section>

      <h2>Platform Features</h2>
      <section className="grid">
        {features.map(f=><article key={f}><h3>{f}</h3><p>Designed for esports tournament operations.</p></article>)}
      </section>
    </main>
  );
}